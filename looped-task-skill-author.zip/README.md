# looped-task-skill-author

Repo-local Codex skill for authoring subskills that guide repeated one-shot agents toward long-horizon or open-ended goals.

Install by copying `.agents/skills/looped-task-skill-author/` into the root of the target repository. Invoke explicitly as `$looped-task-skill-author` when asking Codex to create or revise a recurring loop subskill.

This package is instruction-only. It intentionally contains no scripts, launchers, or automatic validators.
